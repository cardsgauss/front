
import React from 'react';
import axios from 'axios';
import { Paper, Container, Grid } from '@material-ui/core';
import Editing from './editInfo';
import bg from './b.jpg';
import NavbarPage from './newnav';
class AppealForm extends React.Component {
    constructor(props){
        super(props);
        this.state={...Editing.obj};
    }
    handleReason = (event) => {
        this.setState({ reason: event.target.value })}
      onSubmit = (e) => {
        e.preventDefault();
        axios.put(`http://localhost:9000/customer/appeal`,   this.state )
          .then(res => {
              
            if(res.data > 0) {
                
                alert("Appeal submitted successfully");
                axios.post(`http://localhost:9000/customer/appeal1`,   this.state )
                axios.put(`http://localhost:9000/customer/appealstatus`,   this.state )
                .then(res1=>{
                    {
                    let path='appealTable'
                this.props.history.push(path)}
                
                    })
            } else {
                alert("Error submitting appeal");
            }
          })

    }
  

    render() {
        const { fname } = this.state;
         
        return (
            <div>
                <NavbarPage/>
            <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
            <Paper style={{marginLeft:"15%",marginRight:"15%",marginTop:"-4%",paddingTop:10}}>
            <Container maxWidth="xl" style={{marginTop:"5%"}}>
            <Grid>
        <form onSubmit={this.onSubmit}  >
        <div >
        
    
    <div >
        <br></br>
        <h1 style={{alignContent: 'center', textAlign: 'center'}}>Appeal Section</h1>
        
            
                <h5 className="text-center" style={{fontWeight:'600'}} > Appeal Form</h5>
            
            

                <form className="form-horizontal" style={{marginLeft:"35%", marginTop:"5%"}} >
                    <div className="form-group">
                        <label className="control-label col-sm-4" >CustID:</label>
                        <div className="col-md-6">
                            <input type="text" className="form-control" id="id" onChange={this.handleName} value={this.state.id}
               
                               />
                        </div>
                    </div>
                    <div className="form-group">
                            <label className="control-label col-sm-4" >Cust Name</label>
                            <div className="col-md-6">
                                <input type="text" className="form-control" id="name"  name="name"
                                 onChange={this.handleEmail} value={this.state.name}   />
                            </div>
                        </div>
                        
                    
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Credit Score:</label>
                        <div className="col-md-6">
                            <input type="text" className="form-control" id="creditscore" onChange={this.handleAadhaar} value={this.state.score}   name="creditscore"
                                />
                        </div>
                       
                       
                    </div>
                    <div className="form-group">
                        <label className="control-label col-sm-4" >Reason For Appeal:</label>
                        <div className="col-md-6">
                            <input type="text" className="form-control" required onChange={(e) => this.handleReason(e)} value={this.state.reason} id="reason" name="reason"
                                />
                            </div>
                            

                       
                       
                    </div>
                   
                  
                    

                   

                    <div className="but-al">

                        <div className="form-group">
                            <div className=" col-sm-8 col-sm-offset-6">
                                <button  type="submit" className="btn btn-success"  >Submit</button>
                                
                                <button type="reset" className="btn btn-default">Reset</button>
                            </div>
                           
                                    
                        </div>
                        <br></br>
                        <br></br>
                    </div>
                </form>

            </div>
        </div>
    

</form>
</Grid>
</Container>
</Paper>
</div>
</div>
);
    }
}

export default AppealForm;


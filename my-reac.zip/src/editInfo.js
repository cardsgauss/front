class EditInfo{
    constructor()
    {
       this.obj={};
    }
    getobj()
    {
        return this.obj;
    }
    setobj(edit){
        this.obj=edit;
    }
}
let Editing=new EditInfo();
export default Editing;
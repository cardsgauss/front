import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";

import { Paper } from '@material-ui/core';
import { Container } from '@material-ui/core';
import { Grid } from '@material-ui/core';
import bg from './b.jpg';
import NavbarPage from './newnav';

class Table extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: []
      
    }

  }

  componentDidMount() {
    const url = "http://localhost:9000/product/";
    fetch(url, {
      method: "GET"
    }).then(reponse => reponse.json()).then(posts => {
      this.setState({ posts, posts })
    })
  }

    

  render() {
      
    const columns = [
      {
        Header: "Customer id",
        accessor: "id",
        width:150

      },
      {
        Header: "Customer name",
        accessor: "name"
      },
      {
        Header: "Product",
        accessor: "prod_type",
        
        
      },
      {
        Header: "Credit Card No",
        accessor: "card",
        
        
      }
                
    ]
    return (
        <div>
            <NavbarPage/>
      <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
      <Paper style={{marginTop:"-8%"}}>
                <Container maxWidth="xl" style={{marginTop:"10px"}}>
                <Grid>
        <div>
    
      <div style={{textAlign:"center",marginTop:'100px'}}>
    <h2 class="title" style={{paddingTop:'20px'}}>Welcome to Next Generation Onboarding System</h2>
</div>
      <ReactTable
     style={{ marginTop: 30}}
        columns={columns}
        
        data={this.state.posts}
       defaultPageSize={5}
        filterable
      >
      </ReactTable>
      
      </div>
      </Grid>
      </Container>
      </Paper>
      </div>
      </div>
    );
  }
}

export default Table;

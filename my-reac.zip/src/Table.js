import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";
import axios from 'axios';
import editing from './editInfo';
import { Paper } from '@material-ui/core';
import { Container } from '@material-ui/core';
import { Grid } from '@material-ui/core';
import bg from './b.jpg';
import NavbarPage from './newnav';
class Table extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: []
      
    }
    this.state={...editing.obj}

  }

  componentDidMount() {
    const url = "http://localhost:9000/app/";
    fetch(url, {
      method: "GET"
    }).then(reponse => reponse.json()).then(posts => {
      this.setState({ posts, posts })
    })
  }

 deleteRow = (id) => {
    
     axios.delete("http://localhost:9000/app/delete/"+encodeURIComponent(id))
    .then(
      res => {

        if (res.data > 0) {

       alert("Deleted Successfully");
       let path = '/';
        this.props.history.push(path);

      }
      else {
        alert("Error deleting application");
    }
  }

     );
}
editRow=(id)=>{
 
    axios.get("http://localhost:9000/customer/"+encodeURIComponent(id))
    .then((res) => {
       
        editing.obj=res.data;
        let path = 'edit';
    this.props.history.push(path);
    });
}

NextPage=(id)=>{
  
   axios.get("http://localhost:9000/customer/"+encodeURIComponent(id))
    .then((res) => {
     
        editing.obj=res.data;
       
        let path = 'credit';
    this.props.history.push(path);
    });
    
}
  render() {
      
    const columns = [
      {
        Header: "App Id",
        accessor: "appId",
        width:100,maxWidth:100,minWidth:100

      },
      {
        Header: "App Name",
        accessor: "appName"
      },
      {
        Header: "App Status",
        accessor: "status",
        width:200
        
        
      },
      {
        Header: "App Age",
        accessor: "age",
        width:100
      }
      ,
      {
        Header: "Handled by Sales User",
        accessor: "handledBy",
        width:220
      } ,
      {
        Header: "Actions",
        Cell:props=>{
            return(
              
                [
                    
                    <button  className="btn btn-sm " style={{backgroundColor:'#78ADD2',color:'white'}} onClick={()=>{
                        this.editRow(props.original.id);}}>Edit</button>,
        <button className="btn btn-sm btn-success"  style={{marginLeft:10}} onClick={()=>{
            this.NextPage(props.original.id);}}>Next</button>,
                <button type="delete" className="btn btn-sm btn-danger"  style={{marginLeft:10}} onClick={()=>{
                    this.deleteRow(props.original.id);
                }}>Delete</button>
                
                ]
            )
        }
      }
    ]
    return (
      <div>
        <NavbarPage/>
      <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
      <Paper style={{marginTop:"-8%"}}>
                <Container maxWidth="xl" style={{marginTop:"10px"}}>
                <Grid>
        <div>
            
      <div style={{textAlign:"center",marginTop:'100px'}}>
    <h2 class="title" style={{paddingTop:'20px'}}>Welcome to Next Generation Onboarding System</h2>
</div>
      <ReactTable
     style={{ marginTop: 30}}
        columns={columns}
        
        data={this.state.posts}
       defaultPageSize={5}
        filterable
      >
      </ReactTable>
      
      </div>
      </Grid>
      </Container>
      </Paper>
      </div>
      </div>
    );
  }
}

export default Table;

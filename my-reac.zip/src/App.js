import React from 'react';

import './App.css';

import Edit from './edit';
import Existing from './existing';
import {BrowserRouter as Router,Switch,Link,Route} from "react-router-dom";

import AppForm from './appform';
import Table from './Table';
import Approval from './approval';
import CreditScore from './creditscore';
import AppealForm from './appealform';
import DocumentVerification from './document';
import Home from './Home';
import Appeal from './appeal';
import Login from './finallogin';
import Final from './last';
import Popup from './popup';
import Customer from './customers';
import Product from './products';

class App extends React.Component {
 
  render(){
  return (
    <Router>
 
      <Switch>
       <Route  exact path="/" exact component={Login}/>
       <Route  exact path="/home" exact component={Home}/>
       <Route  exact path="/table" exact component={Table}/>
       <Route  exact path="/appealTable" exact component={Appeal}/>
        <Route  exact path="/edit" exact component={Edit}/>
        <Route  exact path="/existing" exact component={Existing}/>
        <Route path="/form" exact component={AppForm}/>
        <Route path="/credit" exact component={CreditScore}/>
        <Route path="/approval" exact component={Approval}/>
        <Route path="/appeal" exact component={AppealForm}/>
        <Route path="/document" exact component={DocumentVerification}/>
        <Route path="/final" exact component={Final}/>
        <Route path="/verify" exact component={Popup}/>
        <Route path="/customer" exact component={Customer}/>
        <Route path="/product" exact component={Product}/>
      </Switch>
      
    </Router>
  )
  }
}

export default App;

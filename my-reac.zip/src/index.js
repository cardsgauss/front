import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';

import Footer from './footer';
import Dashboard from './Dashboard';
import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap-css-only/css/bootstrap.min.css';
import 'mdbreact/dist/css/mdb.css';
import "./assets/scss/mdb.scss"
 ReactDOM.render(<App />, document.getElementById('root1'));

 ReactDOM.render(<Footer/>, document.getElementById('root'));

serviceWorker.unregister();

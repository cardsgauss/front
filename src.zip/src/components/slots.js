import React,{Component} from 'react';
import './style.css';
import {withRouter} from 'react-router-dom';
import {Pie} from 'react-chartjs-2';
import axios from 'axios';

class Park extends Component{
    constructor(props){
        super(props);
        this.state={
          submitted:false,
          customer:[],
          customers:[],
          chartData:{
            labels:[
                'Large',"Medium","Small"
            ],
            datasets:[
              {
                label:'Application Status',
                data:[
            
                ],
                backgroundColor: [    
                'red',
                'green',
                'yellow'
                ]
                  
                
              }
            ]
          }
          
        }
        axios.get("http://localhost:8080/parking/count")
        .then(
            
            (res)=>{console.log(res.data);
                this.setState({customer:res.data})
                console.log(this.state.customer[0].carCount)
                // this.setState(this.state.chartData.datasets[0].data=res.data[0].carCount)
                 var temp=[];
                for(var i=0;i<3;i++)
                {
                    temp.push(5-this.state.customer[i].carCount);
                    if(i==0){
                        localStorage.setItem("large",temp[0])
                    }
                    if(i==1){
                        localStorage.setItem("medium",temp[1])
                    }
                    if(i==2){
                        localStorage.setItem("small",temp[2])
                    }
                }
               

                this.setState(this.state.chartData.datasets[0].data=temp)
            }
            )
   // this.setState(this.state.chartData.datasets[0].data)
      }
    render(){
        return(
            <div>
                <h1 style={{color:"white",textAlign:"center"}}>Vacant Space</h1>
                <Pie 
          data={this.state.chartData}
          height={100}
          width={300}
          
          options={{
             
             legend:{
                 display:true,
                 position:"right"
             },
              maintainAspectRatio: true
        }}
      />
            </div>
        )
    }
}
export default withRouter(Park);














   {/* <div style={{display:"flex"}} >
                <div style={{width:"200px",height:"200px",marginRight:"10px",border:"solid white"}}>
                <h3 style={{color:'white'}}>Large Car Type</h3>
                    <table align="center">
                        <tr>
                            <td style={{color:"white"}}>
                                No. of Vacant Spaces:
                            </td>
                            </tr> <tr>
                            <td>
                                <input style={{backgroundColor:"transparent",color:'white'}}/>
                            </td>
                        </tr>
                    </table>
                </div>
                <div style={{width:"200px",height:"200px",marginRight:"10px",border:"solid white"}}>
                <h3 style={{color:'white'}}>Small Car Type</h3>
                <table align="center">
                        <tr>
                            <td style={{color:"white"}}>
                                No. of Vacant Spaces:
                            </td>
                            </tr> <tr>
                            <td>
                                <input  style={{backgroundColor:"transparent",color:"white"}}/>
                            </td>
                        </tr>
                    </table>
                </div>
                <div style={{width:"200px",height:"200px",border:"solid white"}}>
                <h3 style={{color:'white'}}>Medium Car Type</h3>
                <table align="center">
                        <tr>
                            <td style={{color:"white"}}>
                                No. of Vacant Spaces:
                            </td>
                            </tr> <tr>
                            <td>
                                <input  style={{backgroundColor:"transparent",color:"white"}}/>
                            </td>
                        </tr>
                    </table>
                </div>
                </div>  */}
import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import './style.css';
import axios from 'axios'
import DataTrans from './dataTransfer';

class Bill extends Component {

    constructor(props) {
        super(props);
        this.state = {
            ...DataTrans.obj,
            time: '',
            Bill:''
        }
        console.log(this.state)
        if (this.state.carType == "large") {
            var hms = this.state.currentTime;
            var a = hms.split(':');
            var seconds = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]);
            console.log(seconds);
            var t = new Date();
            var ti = t.getHours() + ":" + t.getMinutes() + ":" + t.getSeconds();
            var z = ti.split(':');
            var seconds1 = (+z[0]) * 60 * 60 + (+z[1]) * 60 + (+z[2]);
            this.state.time =  (seconds1-seconds)/3600;
            if(this.state.time<1)
            {
                this.state.Bill=30;
            }
            else{
                this.state.Bill=Math.round(this.state.time*30);
            }
            
            //this.state.time=this.state.time/3600
            console.log(this.state.time);
        }
        if (this.state.carType == "small") {
            var hms = this.state.currentTime;
            var a = hms.split(':');
            var seconds = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]);
            console.log(seconds);
            var t = new Date();
            var ti = t.getHours() + ":" + t.getMinutes() + ":" + t.getSeconds();
            var z = ti.split(':');
            var seconds1 = (+z[0]) * 60 * 60 + (+z[1]) * 60 + (+z[2]);
            this.state.time =  (seconds1-seconds)/3600;
            if(this.state.time<1)
            {
                this.state.Bill=10;
            }
            else{
                this.state.Bill=Math.round(this.state.time*10);
            }
            
            //this.state.time=this.state.time/3600
            console.log(this.state.time);
        }
        if (this.state.carType == "medium") {
            var hms = this.state.currentTime;
            var a = hms.split(':');
            var seconds = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]);
            console.log(seconds);
            var t = new Date();
            var ti = t.getHours() + ":" + t.getMinutes() + ":" + t.getSeconds();
            var z = ti.split(':');
            var seconds1 = (+z[0]) * 60 * 60 + (+z[1]) * 60 + (+z[2]);
            this.state.time =  (seconds1-seconds)/3600;
            if(this.state.time<1)
            {
                this.state.Bill=20;
            }
            else{
                this.state.Bill=Math.round(this.state.time*20);
            }
            
            //this.state.time=this.state.time/3600
            console.log(this.state.time);
        }
    }
    deleteHandler() {

        axios.delete("http://localhost:8080/parking/delete/" + this.state.carNumber)
            .then(
                console.log(this.state.carNumber),
                alert("Thanks For Visiting"),
                this.props.history.push("/")
            )
    }
    render() {



        return (
            <div className="bg" style={{ textAlign: "center", color: "white" }}>
                <h1>Bill</h1>
                <h3>Standard Chartered Parking</h3>

                <form>
                    <table align="center">
                        <tr >
                            <td style={{ paddingBottom: "10px", paddingRight: "5px" }}>
                                Car Number:
                        </td>
                            <td style={{ paddingBottom: "10px" }}>
                                <input style={{ color: "black" }} value={this.state.carNumber} />
                            </td>
                        </tr>
                        <tr>
                            <td style={{ paddingBottom: "10px", paddingRight: "5px" }}>
                                In Time:
                        </td>
                            <td style={{ paddingBottom: "10px" }}>
                                <input type="text" style={{ color: "black" }}
                                    value={this.state.currentTime} />
                            </td>
                        </tr>
                        <tr>
                            <td style={{ paddingBottom: "10px", paddingRight: "5px" }}>
                                Parking Type:
                        </td>
                            <td style={{ paddingBottom: "10px" }}>
                                <input style={{ color: "black" }}
                                    value={this.state.carType} />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Bill:
                        </td>
                            <td>
                                <input style={{ color: "black" }} 
                                value={this.state.Bill}
                                />
                            </td>
                        </tr>
                    </table>
                    <button type="submit" onClick={() => this.deleteHandler()} style={{ backgroundColor: "#0072aa", marginTop: "10px", fontSize: "15px", border: "0px", borderRadius: "5px" }}>Pay</button>
                    <h4>Thank You for Visiting</h4>
                </form>
            </div>
        )
    }
}
export default withRouter(Bill);
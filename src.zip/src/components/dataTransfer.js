class DataTransfer{
    constructor()
    {
        this.obj={};
    }
    getobj(){
        return this.obj;
    }
    setobj(edit){
        this.obj=edit;
    }
}
let DataTrans=new DataTransfer();
export default DataTrans;
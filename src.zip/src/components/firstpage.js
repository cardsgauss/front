import React,{Component} from 'react';
import './style.css';
import {withRouter} from 'react-router-dom';
import axios from 'axios';
import DataTrans from './dataTransfer';
import Park from './slots'

class FirstPage extends Component{
    state={
        data:'',
        type:'',
        carData:[]
    }
    changeHandler(event){
        this.setState({data:event.target.value})
    
    }
    selectHandler(event){
        this.setState({type:event.target.value})

    }
    showDataHandler(){
        // let dat=new Date();
        // alert(dat);
       
       
        this.carData={
          carNumber:this.state.data,
          carType:this.state.type
        }
        if(this.state.type=="large")
        { 
          if(localStorage.getItem("large")>0){
            axios.post("http://localhost:8080/parking/add",this.carData)
            .then(//alert("added successfully"),
            this.props.history.push("/"))
          }
          else{
            alert("No Large Space Available");
          }
         
        }
        if(this.state.type=="small")
        { 
          if(localStorage.getItem("small")>0){
            axios.post("http://localhost:8080/parking/add",this.carData)
            .then(//alert("added successfully"),
            this.props.history.push("/"))
          }
          else{
            alert("No Small Space Available");
          }
         
        }
        if(this.state.type=="medium")
        { 
          if(localStorage.getItem("medium")>0){
            axios.post("http://localhost:8080/parking/add",this.carData)
            .then(//alert("added successfully"),
            this.props.history.push("/"))
          }
          else{
            alert("No Medium Space Available");
          }
         
        }
       
             }

    exitHandler(){
        // alert("exit")
       
        axios.get("http://localhost:8080/parking/get/"+this.state.data)
        .then((res)=>{
            console.log(res.data);
           // this.setState({parking:res.data})
           DataTrans.obj=res.data[0];
          console.log(DataTrans.obj);
          
          this.props.history.push("/Bill"); 
        })
        // localStorage.setItem("type",this.state.type)
         
    }
    render(){
        return(
            <div className="col-md-12 bg">
                <h1 style={{textAlign:"center",color:"white",fontFamily:"montserrat",paddingTop:"30px",paddingBottom:"50px"}}>Welcome to Smart Parking System</h1>
                <div style={{display:"flex"}}>
                <div className="col-md-4" style={{textAlign:"center",marginTop:"10%"}}>
                <button  style={{width:"100px",height:"100px",backgroundColor:"Green",fontFamily:"montserrat",fontSize:"30px",border:"0px",borderRadius:"5px",marginRight:"100px"}} type="button"
                data-toggle="modal" data-target="#myModal" >Park</button>
               
                <button  style={{width:"100px",height:"100px",backgroundColor:"red",fontFamily:"montserrat",fontSize:"30px",border:"0px",borderRadius:"5px"}} type="button" data-toggle="modal" data-target="#myModal1" >Exit</button>
                </div>
                <div className="col-md-8" style={{fontFamily:"montserrat"}}>
                  <Park  carType={this.state.type}/>
                </div>
                </div>
                <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Enter Your Details</h4>
      </div>
      <div class="modal-body">
      <p>Enter Your Car Number:</p>
        <input type="text" style={{borderRadius:"5px"}} 
         onChange={(event)=>this.changeHandler(event)}
        required/>
        <div style={{marginTop:"10px"}}>
        <p>Select type of Space required.</p>

<select id="mySelect" onChange={(event)=>this.selectHandler(event)} style={{borderRadius:"5px"}}>
<option value="">--select--</option>
  <option value="small">Small</option>
  <option value="medium">Medium</option>
  <option value="large">Large</option>
</select>
</div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-default" data-dismiss="modal" onClick={(event)=>this.showDataHandler(event)}>Park</button>
      </div>
    </div>

  </div>
</div>
<div id="myModal1" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Enter Your Details</h4>
      </div>
      <div class="modal-body">
      <p> Your Car Number:</p>
        <input type="text" style={{borderRadius:"5px"}} onChange={(event)=>this.changeHandler(event)} required/>
        
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" onClick={()=>this.exitHandler()} >Exit</button>
      </div>
    </div>

  </div>
</div>

            </div>
            </div>
        )
    }
}
export default withRouter(FirstPage);
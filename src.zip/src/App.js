import React from 'react';
import logo from './logo.svg';
import './App.css';
import FirstPage from './components/firstpage';
import {BrowserRouter,withRouter, Switch,Route} from 'react-router-dom';
import Bill from './components/bill';
import Park from './components/slots';


function App() {
  return (
  <div>
<BrowserRouter>
<Switch>
  <Route path="/"exact component ={FirstPage}/>
  <Route path="/Bill"exact component ={Bill}/>
  <Route path="/Park"exact component ={Park}/>
  </Switch>
</BrowserRouter>
    {/* <FirstPage/> */}
  </div>
  );
}

export default App;
